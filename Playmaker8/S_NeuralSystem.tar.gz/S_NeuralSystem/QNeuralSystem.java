package S_NeuralSystem;

import Jama.Matrix;
import fzdeepnet.Setting;
import fzdeepnet.Setting.Trainer;

public abstract class QNeuralSystem extends NeuralSystem{
	Matrix currState;
	Matrix currAction;	
	Matrix nextState;
	Matrix bestAction;
	double reward;
	
	public QNeuralSystem(Setting.Model mConf)throws Exception{
		super(mConf);
	}		
	public abstract void setState(Matrix s); // Set current state
	public abstract void setAction(Matrix a); // Set action in current state
	public abstract void setNextState(Matrix s); // Set next state
	public abstract void setMaxAction(Matrix a); // Set max action in next state
	public abstract void setReward(double r); // Set reward
}
