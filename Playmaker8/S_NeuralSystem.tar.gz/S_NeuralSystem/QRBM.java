package S_NeuralSystem;

public class QRBM {
	// Q-learning with mix-odered RBM
	
}
