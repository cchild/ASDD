package S_NeuralSystem;

import Jama.Matrix;

public class SoftmaxLayer extends Layer {
	
	public SoftmaxLayer(String lid, int dimension){
		super(lid, dimension);
	}
	
	@Override
	void computeOutMessage() {
		// TODO Auto-generated method stub

	}

	@Override
	void activate() {
		// TODO Auto-generated method stub

	}

	@Override
	Matrix grad() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	Layer copyStateLayer() {
		// TODO Auto-generated method stub
		return null;
	}

}
