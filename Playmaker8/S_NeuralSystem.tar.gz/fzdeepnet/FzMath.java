package fzdeepnet;

import Jama.Matrix;

public class FzMath {

	public static Matrix log(Matrix m){
		Matrix x = m.copy();
		int col = m.getColumnDimension();
		int row = m.getRowDimension();
		for(int i=0;i<row;i++){
			for(int j=0;j<col;j++){
				x.set(i, j, Math.log(m.get(i,j)));
			}
		}
		return x;
	}
	
	public static Matrix exp(Matrix m){
		Matrix x = m.copy();
		int col = m.getColumnDimension();
		int row = m.getRowDimension();
		for(int i=0;i<row;i++){
			for(int j=0;j<col;j++){
				x.set(i, j, Math.exp(m.get(i,j)));
			}
		}
		return x;
	}
	
	public static Matrix logistic(Matrix m){
		Matrix x = m.copy();
		int col = m.getColumnDimension();
		int row = m.getRowDimension();
		for(int i=0;i<row;i++){
			for(int j=0;j<col;j++){
				x.set(i, j, 1/(1+Math.exp(-m.get(i,j))));
			}
		}
		return x;
	}
	
	public static void printMatrixShape(Matrix m){
		int col = m.getColumnDimension();
		int row = m.getRowDimension();
		System.out.println(row + " x " + col);
	}
	
	public static Matrix initializeMatrix(int m,int n){		
		Matrix mtx =  Matrix.random(m,n).times(0.001);
		//mtx.print(1, 5);
		return mtx;
	}
	public static Matrix repmat(Matrix x,int m,int n){
		// Need to double check
		// Replicate matrix to m row and n column
		int row = x.getRowDimension();
		int col = x.getColumnDimension();
		Matrix mtx = new Matrix(row*m,col*n);
		if((m>1 && n>0) || (n>1 && m>0)){
			for(int i=0;i<m;i++){
				for(int j=0;j<n;j++){ 
					mtx.setMatrix(i*row, (i+1)*row-1,j*col,(j+1)*col-1,x);
				}
			}
		}else{
			mtx= x.copy();
		}
		return mtx;
	}
}

